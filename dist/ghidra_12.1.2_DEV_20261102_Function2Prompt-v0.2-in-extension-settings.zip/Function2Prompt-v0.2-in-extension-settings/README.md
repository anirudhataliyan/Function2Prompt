# Function2Prompt v0.2

A Ghidra 12.x extension that decompiles the function under the current cursor,
includes an embedded OpenAI-powered chat panel, copies a structured prompt to the clipboard, and saves a Markdown report
in the same directory as the original executable (when Ghidra has its source path).
The AI panel sends the selected function and chat context to an OpenAI-compatible Chat Completions API. Configure the endpoint, model and API key directly in the panel; no environment variables are required.

## Requirements
- Ghidra 12.x
- JDK 21
- The Gradle version recommended by your Ghidra distribution

## 1. Find the actual Ghidra installation root

`/usr/bin/ghidra` is likely a launcher or wrapper, not the installation root.
The root must contain `support/buildExtension.gradle`.

Run:

```bash
readlink -f /usr/bin/ghidra
command -v ghidraRun
sudo find /opt /usr/local /usr/share -path '*/support/buildExtension.gradle' -print 2>/dev/null
```

Use the directory containing `support/`, `Ghidra/`, and `Extensions/`. Do not assume
it is `/usr/bin`.

## 2. Build

From this project directory:

```bash
export GHIDRA_INSTALL_DIR="/absolute/path/to/ghidra-root"
java -version
"$GHIDRA_INSTALL_DIR/support/gradle/gradlew" buildExtension
```

If the distribution does not include that Gradle wrapper, use a compatible Gradle
version as specified by the Ghidra installation:

```bash
gradle buildExtension
```

Find the generated ZIP:

```bash
find . -type f -name '*.zip' | grep -E '/(dist|build/distributions)/'
```

## 3. Install

1. Start Ghidra and open the project window.
2. Select **File → Install Extensions**.
3. Click the add (+) control and select the generated Function2Prompt ZIP.
4. Enable it, confirm, and restart Ghidra.

## 4. Use

1. Open a program in CodeBrowser and wait for analysis to finish.
2. Put the cursor at an address inside the function.
3. Choose **Tools → Function2Prompt → Export Function for ChatGPT**, or use the
   right-click popup menu.
4. Paste the clipboard contents into ChatGPT.

## 5. Configure and use the embedded AI panel

1. Open **Tools → Function2Prompt → Open AI Assistant**.
2. Enter an API endpoint, model ID and API key in the settings at the top of the panel.
3. Click **Save settings**. Settings are saved in the current operating-system user's Java Preferences and restored the next time Ghidra starts.
4. Click **Analyse current function**, then enter follow-up questions and click **Send**.

The default configuration is OpenRouter:

- Endpoint: `https://openrouter.ai/api/v1/chat/completions`
- Model: `openrouter/free`

Other OpenAI-compatible examples:

| Provider | Endpoint | Model |
|---|---|---|
| OpenAI | `https://api.openai.com/v1/chat/completions` | A model enabled for your API project |
| OpenRouter | `https://openrouter.ai/api/v1/chat/completions` | `openrouter/free` or a specific available model |
| Ollama | `http://localhost:11434/v1/chat/completions` | A model installed locally in Ollama |

Use a provider's exact documented endpoint and model ID. A ChatGPT subscription does not include API credits; provider API usage may be billed separately.

**API-key storage:** the key is saved in Java Preferences for the current OS user so you do not need to set an environment variable. Java Preferences does not guarantee encrypted secret storage. Use a dedicated, low-privilege API key, protect your OS account, and remove the key from the panel/preferences if you no longer need it. Never commit keys to GitHub.

**Privacy:** the decompiled function and chat context are sent to the configured provider. With Ollama on localhost, requests can stay on your machine. Do not transmit proprietary or confidential code to an external provider unless authorized.

## Troubleshooting

- **No function at cursor:** move the cursor inside a defined function.
- **Decompilation failed:** wait for analysis to finish and retry.
- **Clipboard error:** run Ghidra in a graphical desktop session with a working clipboard.
- **Incompatible extension:** rebuild against the exact Ghidra installation.
- **Gradle/JDK error:** use JDK 21 and the Gradle version in
  `Ghidra/application.properties`.

## Scope and safety

The extension exports decompiled code and metadata. Review the report before sharing
it. Do not send proprietary or confidential code to an external service unless you
are authorized to do so.

v0.2 adds a basic embedded AI chat panel and one-function-at-a-time analysis. Recursive callee collection, cross-reference enrichment, streaming responses, and whole-program analysis are not implemented yet.
